package com.proyecto.uade.GestionTurnoProfesionalSalud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionTurnoProfesionalSaludApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionTurnoProfesionalSaludApplication.class, args);
	}

}
